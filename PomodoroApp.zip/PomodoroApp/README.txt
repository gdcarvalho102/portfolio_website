PomodoroApp – Temporizador de Foco

Como usar:
1. Clique duas vezes no arquivo "Pomodoro" para iniciar o app.
2. Certifique-se de que os arquivos:
   - alarm_sound.wav
   - pomodoro_config.toml
   - pomodoro_app.db
   - tasks_10.csv (opcional)
   estão na mesma pasta do executável.

Requisitos:
- macOS 10.15 ou superior
- Permitir execução de apps de desenvolvedores não identificados em Preferências do Sistema → Segurança e Privacidade

Bom foco! 🍅⏱️
